#!/bin/bash
# Andrew Berg CEN4020 Leadboards Just My Type
source ./flask/bin/activate
python createdb.py
python leaderboards.py